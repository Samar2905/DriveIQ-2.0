HOW TO DEPLOY IVY (5 minutes, free)
=====================================

1. Go to vercel.com → sign up free (use Google login)

2. Click "Add New Project" → then "Browse" and select this entire ivy-deploy folder

3. BEFORE clicking Deploy, look for "Environment Variables" and add:
   Name:  GROQ_API_KEY
   Value: your gsk_... key from console.groq.com

4. Click Deploy → done! You get a free URL like ivy-deploy.vercel.app

That's it. Your Groq key is safe and hidden. No one can steal it.
